(function($) {
  "use strict";

  $(document).ready(function() {
    var container = $("#marketplace-container");
    var marketplaceUrl = mpauthData.marketplaceUrl || 'https://keka-marketplace-production.up.railway.app';
    var marketplaceOrigin = new URL(marketplaceUrl).origin;

    function refreshMarketplaceAuth() {
      var iframe = document.getElementById('marketplace-iframe');
      if (iframe) {
        if (mpauthData.isLoggedIn) {
          $.ajax({
            url: mpauthData.apiUrl,
            method: "GET",
            beforeSend: function(xhr) {
              xhr.setRequestHeader('X-WP-Nonce', mpauthData.nonce);
            },
            success: function(data) {
              if (data.token) {
                var newUrl = marketplaceUrl;
                newUrl += (newUrl.indexOf("?") > -1 ? "&" : "?") + "token=" + encodeURIComponent(data.token);
                iframe.src = newUrl;
              } else {
                iframe.src = marketplaceUrl;
              }
            },
            error: function() {
              iframe.src = marketplaceUrl;
            }
          });
        } else {
          iframe.src = marketplaceUrl;
        }
      }
    }

    function loadMarketplaceIframe(url) {
      container.html(
        '<iframe src="' + url + '" ' +
        'id="marketplace-iframe" ' +
        'width="100%" ' +
        'height="800" ' +
        'style="border:none; min-height:800px; width:100%; max-width:100%; overflow:hidden;" ' +
        'allow="clipboard-read; clipboard-write" ' +
        'scrolling="yes"></iframe>'
      );

      window.addEventListener('message', function(event) {
        if (event.origin !== marketplaceOrigin) return;

        const iframeWindow = event.source;

        switch (event.data.action) {
          case 'requireLogin':
            window.location.href = mpauthData.loginUrl;
            break;
          case 'requestLogout':
            window.location.href = mpauthData.loginUrl.replace('wp-login.php', 'wp-login.php?action=logout&_wpnonce=' + mpauthData.nonce);
            break;
          case 'resize':
            if (event.data.height) {
              $('#marketplace-iframe').height(event.data.height);
            }
            break;
          case 'checkLoginStatus':
            iframeWindow.postMessage({
              action: 'loginStatus',
              isLoggedIn: mpauthData.isLoggedIn,
              user: mpauthData.user || null
            }, event.origin);
            break;
        }
      });
    }

    if (mpauthData.isLoggedIn) {
      $.ajax({
        url: mpauthData.apiUrl,
        method: "GET",
        beforeSend: function(xhr) {
          xhr.setRequestHeader('X-WP-Nonce', mpauthData.nonce);
        },
        success: function(data) {
          if (data.token) {
            sessionStorage.setItem("wp_marketplace_token", data.token);
            marketplaceUrl += (marketplaceUrl.indexOf("?") > -1 ? "&" : "?") + "token=" + encodeURIComponent(data.token);
            loadMarketplaceIframe(marketplaceUrl);
          } else {
            loadMarketplaceIframe(marketplaceUrl);
          }
        },
        error: function() {
          loadMarketplaceIframe(marketplaceUrl);
          console.error("Failed to get authentication token.");
        }
      });
    } else {
      loadMarketplaceIframe(marketplaceUrl);
    }

    $(window).on('focus', function() {
      setTimeout(refreshMarketplaceAuth, 500);
    });
  });
})(jQuery);
